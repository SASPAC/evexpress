filename PE22DD66 list;

 %put NOTE- ;
 %put NOTE: Loading package evExpress, version 0.0.2, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2025-12-09T11:44:00; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Run %nrstr(%%)helpPackage(evExpress) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_; 
 if NOT ("*"=symget("cherryPick")) then do; 
  put "NOTE- "; 
  put "NOTE: *** Cherry Picking ***"; 
  put "NOTE- Cherry Picking in action!! Be advised that"; 
  put "NOTE- dependencies/required packages will not be loaded!"; 
  put "NOTE- "; 
 end; 
run; 
%include  PE22DD66(packagemetadata.sas) / nosource2; 

 
%if (%str(*)=%superq(cherryPick)) or (evexpressds in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "evexpressds.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(evexpressds)=1, NOTE# Macro evexpressds exist. It will be overwritten by the macro from the evExpress package, ));
  %include PE22DD66(_010_macro.evexpressds.sas) / nosource2;
%end; 

data _null_; 
  call symputX('cherryPick_FCMP', exist('work.evExpressfcmp'), 'L'); 
run; 
proc fcmp outlib = work.evExpressfcmp.package ; 
 
%if (%str(*)=%superq(cherryPick)) or (evexpress in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "evexpress.sas" will be included <<;
  %include PE22DD66(_020_functions.evexpress.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

%sysfunc(ifc(0<
  %sysfunc(findw((%sysfunc(getoption(cmplib)))
                ,work.evexpressfcmp,"'( )'",RIO))
,,%str(options APPEND=(cmplib = work.evexpressfcmp);)
))
 
%if (%str(*)=%superq(cherryPick)) or (evexpressc in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "evexpressc.sas" will be included <<;
  %include PE22DD66(_020_functions.evexpressc.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (evexpresscq in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "evexpresscq.sas" will be included <<;
  %include PE22DD66(_020_functions.evexpresscq.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (evexpressq in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "evexpressq.sas" will be included <<;
  %include PE22DD66(_020_functions.evexpressq.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

quit; 

data _null_;                                   
  call symputX("cherryPick_CASLUDF",  0, "L"); 
run;                                           
data _null_;
length CASLUDF $ 32767;
dtCASLudf = datetime();
CASLUDF =                                      
    '%macro evExpressCASLudf('         
 !! "list=1,depList="                          
 !! ')/ des = ''CASL User Defined Functions loader for evExpress package'';'
 !! '  %if HELP = %superq(list) %then                               '
 !! '    %do;                                                       '
 !! '      %put ****************************************************************************;'
 !! '      %put This is help for the `evExpressCASLudf` macro;'
 !! '      %put Parameters (optional) are the following:;'
 !! '      %put - `list` indicates if the list of loaded CASL UDFs should be displayed,;'
 !! '      %put %str(  )when set to the value of `1` (the default) runs `FUNCTIONLIST USER%str(;)`,;'
 !! '      %put %str(  )when set to the value of `HELP` (upcase letters!) displays this help message.;'
 !! '      %put - `depList` [technical] contains the list of dependencies required by the package.;'
 !! '      %put %str(  )for _this_ instance of the macro the default value is: `.;'
 !! '      %put The macro generated: ' !! put(dtCASLudf, E8601DT19.-L) !! ";"
 !! '      %put with the SAS Packages Framework version 20251126.;'
 !! '      %put ****************************************************************************;'
 !! '    %GOTO theEndOfTheMacro;'
 !! '    %end;'
 !! '  %if %superq(depList) ne %then                                '
 !! '    %do;                                                       '
 !! '      %do i = 1 %to %sysfunc(countw(&depList.,%str( )));       '
 !! '        %let depListNm = %scan(&depList.,&i.,%str( ));         '
 !! '        %if %SYSMACEXIST(&depListNm.CASLudf) %then             '
 !! '          %do;                                                 '
 !! '            %&depListNm.CASLudf(list=0)                        '
 !! '          %end;                                                '
 !! '      %end;                                                    '
 !! '    %end;                                                      '
 !! '  %local tmp_NOTES;'                                                                     
 !! '  %let tmp_NOTES = %sysfunc(getoption(NOTES));'                                          
 !! "  filename PE22DD66 &ZIP. '&path./evexpress.&zip.';"
 !! "  options nonotes;"                      
 !! '  filename PE22DD66 clear;'    
 !! '  options &tmp_NOTES.;'                
 !! '   %if 1 = %superq(list) %then '       
 !! '     %do; '                            
 !! "       FUNCTIONLIST USER;"               
 !! "       run;"                             
 !! '     %end; '                           
 !! '%theEndOfTheMacro: %mend;';            
run;

%if 0 = &cherryPick_FCMP. %then %do;
options cmplib = (%unquote(%sysfunc(tranwrd(
%sysfunc(lowcase(%sysfunc(getoption(cmplib))))
,%str(work.evexpressfcmp), %str() ))));
options cmplib = (%unquote(%sysfunc(compress(
%sysfunc(getoption(cmplib))
,%str(()) ))));
%end;
data _null_;
run;
data _null_;
run;
%put NOTE- ;
%put NOTE:[CMPLIB] %sysfunc(getoption(cmplib));

options noNotes;
%if (%str(*)=%superq(cherryPick)) %then %do; 
 data _null_ ;                                                                                              
  length SYSloadedPackages stringPCKG $ 32767;                                                              
  if SYMEXIST("SYSloadedPackages") = 1 and SYMGLOBL("SYSloadedPackages") = 1 then                           
    do;                                                                                                     
      do until(EOF);                                                                                        
        set sashelp.vmacro(where=(scope="GLOBAL" and name="SYSLOADEDPACKAGES")) end=EOF;                    
        substr(SYSloadedPackages, 1+offset, 200) = value;                                                   
      end;                                                                                                  
      SYSloadedPackages = cats("#", translate(strip(SYSloadedPackages), "#", " "), "#");                    
      indexPCKG = INDEX(lowcase(SYSloadedPackages), '#evexpress(');                  
      if indexPCKG = 0 then                                                                                 
         do;                                                                                                
          SYSloadedPackages = catx('#', SYSloadedPackages, 'evExpress(0.0.2)');              
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                               
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                        
          put / "INFO:[SYSLOADEDPACKAGES] " SYSloadedPackages ;                                             
         end ;                                                                                              
      else                                                                                                  
         do;                                                                                                
          stringPCKG = kscanx(substr(SYSloadedPackages, indexPCKG+1), 1, '#');                              
          SYSloadedPackages = compbl(tranwrd(SYSloadedPackages, strip(stringPCKG), "#"));                   
          SYSloadedPackages = catx('#', SYSloadedPackages, 'evExpress(0.0.2)');              
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                               
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                        
          put / "INFO:[SYSLOADEDPACKAGES] " SYSloadedPackages ;                                             
         end ;                                                                                              
    end;                                                                                                    
  else                                                                                                      
    do;                                                                                                     
      call symputX('SYSloadedPackages', 'evExpress(0.0.2)', 'G');                            
      put / 'INFO:[SYSLOADEDPACKAGES] evExpress(0.0.2)';                                      
    end;                                                                                                    
  stop;                                                                                                     
 run;                                                                                                       
%end; 

options NOTES;
%put NOTE- ;
%put NOTE: Loading package evExpress, version 0.0.2, license MIT;
%put NOTE- *** END ***;

options &temp_noNotes_etc.;
%symdel temp_noNotes_etc / noWarn;
/* load.sas end */


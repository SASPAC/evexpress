Type: Package
Package: evExpress
Title: Evaluate text string as an expression in SAS
Version: 0.0.2
Author: Bartosz Jablonski (yabwon@gmail.com)
Maintainer: Bartosz Jablonski (yabwon@gmail.com)
License: MIT
Encoding: UTF8

DESCRIPTION START:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

The `evExpress` package is a bunch of macros and functions
design to help evaluate SAS expressions that are provided
in a form of a text string.

Under the hood the `DoSubL()` finction is used, this means
that the package is not desing for a big number of expressions.
If the number of expresions exceeds 10000, consider other
options because the total time of execution may exceed your
expectations (for example, a batch of 6000 expressions took
around 16 secods on the test machine).

See examples for more details.

DESCRIPTION END:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

filename PE22DD66 list;

 %put NOTE- ;
 %put NOTE: Data for package evExpress, version 0.0.2, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2025-12-09T11:44:00; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Write %nrstr(%%)helpPackage(evExpress) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_;
 length lazyData $ 32767; lazyData = lowcase(symget("lazyData"));
run;
%put NOTE- ;
%put NOTE: Data for package evExpress, version 0.0.2, license MIT;
%put NOTE- *** END ***;

/* lazydata.sas end */


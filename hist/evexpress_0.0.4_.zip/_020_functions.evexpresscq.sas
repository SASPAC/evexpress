/* File generated with help of SAS Packages Framework, version 20260216. */

/*** HELP START ***//*

### DESCRIPTION: ##############################################################

The `evExpress()`, `evExpressQ()`, `evExpressC()`, and `evExpressCQ()` 
functions allow for automatic evaluation of expressions provided in form 
of a text string in context of an observation from an input data set. 

Functions *without* `C` assume the result of the evaluation is *numeric*,
but functions with `C` at the end return *character* value.

All functions expect 3 parameters:
`expression`, `indsname`, and `curobs`.

The first parameter is a name of a variable with a string to be evaluated.
The second is the name of a data set with data used in evaluation.
The third is the observation number (from that data set) for which
evaluation is done.

When the `evExpress<C>()` is executed, if there is an error during 
the evaluation, for every observation a warning is issued and 
all error messages are printed in the log.

Implicit types conversion is considered an error.

When the `evExpress<C>Q()` is executed (`Q` stands for *quiet*) 
no error messages are printed in the log.

For every DATA step using the `evExpress<C>()` function two global 
macro variables are created:
- `EEF_CHECK_****************` and 
- `EEF_PASSED_****************`.

The `evExpress<C>Q()` creates only the second macro variable.

Those asterisks represent `hex16.` formatted value 
of the timestamp of the execution start. Those macro variables 
are not automatically removed from the session.

### SYNTAX: ###################################################################

The basic syntax is the following, the `<...>` means optional parameters:
~~~~~~~~~~~~~~~~~~~~~~~sas
var1 = evExpress<C>(
  expression 
, indsname 
, curobs
);

var2 = evExpress<C>Q(
  expression 
, indsname 
, curobs
);
~~~~~~~~~~~~~~~~~~~~~~~

**Arguments description**:

1. `expression` - *Required.* Character variable containing
                   string with expression to be evaluated.

2. `indsname`   - *Required.* Character variable containing 
                   the name of a data set with variables
                   used in evaluation. If the `expression` 
                   variable contains only constant expressions 
                   (i.e., expressions not using any variables, 
                   like: `46 & 2` or `21 + 21`) an empty string 
                   can be provided as the value.

3. `curobs`     - *Required.* Numeric variable containing
                   number of an observation that will provide 
                   data used during the evaluation.

---

*//*** HELP END ***/

function evExpressCQ(expression $, indsname $, curobs) $ 32767;
  file log;
  length macVarNamePassed $ 32 rc 8 marker $ 16;
  static done 0 macVarNamePassed;

  if not done then
    do;
      marker=put(datetime(),hex16.);
      macVarNamePassed=catx("_","EEFQ_PASSED",marker);
      /*put macVarNamePassed=;*/
      done=1;
    end;

  rc = DoSubL(
    'filename ___D___ DUMMY; proc printto log=___D___; run;' !! 
    '%let ' !! macVarNamePassed !! '=.;' !!
    'data _null_ / NOTE2ERR;' !! 
    ifc(indsname=" "
       ," "
       ,cat('set ', strip(indsname), '(firstobs = ', max(curobs,1), ' obs = ', max(curobs,1), ');')) !! 
    ' call symputX("' !! macVarNamePassed !! '",(' !! strip(expression) !! '), "G"); stop; run;'
    );

  length resultExpr $ 32767;
  resultExpr = symget(macVarNamePassed);

  return(resultExpr);
endfunc;


/**###################################################################**/
/*                                                                     */
/*  Copyright Bartosz Jablonski, since 2025 onward.                    */
/*                                                                     */
/*  Code is under the MIT license. If you want - you can use it.       */
/*  But it comes "AS IS", with absolutely no warranty whatsoever.      */
/*  If you cause any damage or something - it will be your own fault.  */
/*  You've been warned! You are using it on your own risk.             */
/*                                                                     */
/*  However, if you decide to use it, you are obligated to mention     */
/*  the author Bartosz Jablonski (yabwon@gmail.com)                    */
/*                                                                     */
/**###################################################################**/


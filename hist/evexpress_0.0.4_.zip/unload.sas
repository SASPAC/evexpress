filename PE22DD66 list;
%put NOTE: Unloading package evExpress, version 0.0.4, license MIT;
%put NOTE- *** START ***;
proc sql;
  create table WORK._%sysfunc(datetime(), hex16.)_ as
  select memname, objname, objtype
  from dictionary.catalogs
  where 
  (
   objname in ("*"
   ,'EVEXPRESSMETA'
   ,'EVEXPRESSIML'
   ,'EVEXPRESSCASLUDF'
   %put NOTE- Element of type macro generated from the file "evexpressds.sas" will be deleted;
   %put NOTE- ;
   ,"EVEXPRESSDS                                                     "
  )
  and objtype = "MACRO"
  and libname  = "WORK"
  )
  or
  (
   objname in ("*"
  )
  and objtype in ("FORMAT" "FORMATC" "INFMT" "INFMTC")
  and libname  = "WORK"
  and memname = 'EVEXPRESSFORMAT'
  )
  order by objtype, memname, objname
  ;
quit;
data _null_;
  do until(last.memname);
    set WORK._last_;
    by objtype memname;
    if first.memname then call execute("proc catalog cat = work." !! strip(memname) !! " force;");
    call execute("delete " !! strip(objname) !! " /  et =" !! objtype !! "; run;");
  end;
  call execute("quit;");
run;
proc delete data = WORK._last_;
run;
proc fcmp outlib = work.evExpressfcmp.package;
%put NOTE- Element of type functions generated from the file "evexpress.sas" will be deleted;
%put NOTE- ;
deletefunc evexpress ;
%put NOTE- Element of type functions generated from the file "evexpressc.sas" will be deleted;
%put NOTE- ;
deletefunc evexpressc ;
%put NOTE- Element of type functions generated from the file "evexpresscq.sas" will be deleted;
%put NOTE- ;
deletefunc evexpresscq ;
%put NOTE- Element of type functions generated from the file "evexpressq.sas" will be deleted;
%put NOTE- ;
deletefunc evexpressq ;
quit;

proc fcmp outlib = work.evExpressfcmp.packagemeta;
deletefunc evExpressMETA;
quit;

options cmplib = (%unquote(%sysfunc(tranwrd(
%sysfunc(lowcase(%sysfunc(getoption(cmplib))))
,%str(work.evexpressfcmp), %str() ))));
options cmplib = (%unquote(%sysfunc(compress(
%sysfunc(getoption(cmplib))
,%str(()) ))));
%put; %put NOTE:[CMPLIB] %sysfunc(getoption(cmplib));
proc SQL noprint;
quit;

data _null_; call symputx("_DS2_2_del_",0,"L"); run;
proc SQL noprint;
quit;

run;

data _null_ ;                                                                                         
  length SYSloadedPackages $ 32767;                                                                   
  if SYMEXIST("SYSloadedPackages") = 1 and SYMGLOBL("SYSloadedPackages") = 1 then                     
    do;                                                                                               
      do until(EOF);                                                                                  
        set sashelp.vmacro(where=(scope="GLOBAL" and name="SYSLOADEDPACKAGES")) end=EOF;              
        substr(SYSloadedPackages, 1+offset, 200) = value;                                             
      end;                                                                                            
      SYSloadedPackages = cats("#", translate(strip(SYSloadedPackages), "#", " "), "#");              
      if INDEX(lowcase(SYSloadedPackages),'#evexpress(0.0.4)#')>0 then 
         do;                                                                                          
          SYSloadedPackages = tranwrd(SYSloadedPackages, '#evExpress(0.0.4)#', '##');  
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                         
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                  
          put "NOTE: " SYSloadedPackages = ;                                                          
         end ;                                                                                        
    end;                                                                                              
  stop;                                                                                               
run;                                                                                                  
%put NOTE: Unloading package evExpress, version 0.0.4, license MIT;
%put NOTE- *** END ***;
%put NOTE- ;
/* unload.sas end */

/* File generated with help of SAS Packages Framework, version 20260216. */

/*** HELP START ***//*

### DESCRIPTION: ##############################################################

The `evExpress()`, `evExpressQ()`, `evExpressC()`, and `evExpressCQ()` 
functions allow for automatic evaluation of expressions provided in form 
of a text string in context of an observation from an input data set. 

Functions *without* `C` assume the result of the evaluation is *numeric*,
but functions with `C` at the end return *character* value.

All functions expect 3 parameters:
`expression`, `indsname`, and `curobs`.

The first parameter is a name of a variable with a string to be evaluated.
The second is the name of a data set with data used in evaluation.
The third is the observation number (from that data set) for which
evaluation is done.

When the `evExpress<C>()` is executed, if there is an error during 
the evaluation, for every observation a warning is issued and 
all error messages are printed in the log.

Implicit types conversion is considered an error.

When the `evExpress<C>Q()` is executed (`Q` stands for *quiet*) 
no error messages are printed in the log.

For every DATA step using the `evExpress<C>()` function two global 
macro variables are created:
- `EEF_CHECK_****************` and 
- `EEF_PASSED_****************`.

The `evExpress<C>Q()` creates only the second macro variable.

Those asterisks represent `hex16.` formatted value 
of the timestamp of the execution start. Those macro variables 
are not automatically removed from the session.

### SYNTAX: ###################################################################

The basic syntax is the following, the `<...>` means optional parameters:
~~~~~~~~~~~~~~~~~~~~~~~sas
var1 = evExpress<C>(
  expression 
, indsname 
, curobs
);

var2 = evExpress<C>Q(
  expression 
, indsname 
, curobs
);
~~~~~~~~~~~~~~~~~~~~~~~

**Arguments description**:

1. `expression` - *Required.* Character variable containing
                   string with expression to be evaluated.

2. `indsname`   - *Required.* Character variable containing 
                   the name of a data set with variables
                   used in evaluation. If the `expression` 
                   variable contains only constant expressions 
                   (i.e., expressions not using any variables, 
                   like: `46 & 2` or `21 + 21`) an empty string 
                   can be provided as the value.

3. `curobs`     - *Required.* Numeric variable containing
                   number of an observation that will provide 
                   data used during the evaluation.

---

*//*** HELP END ***/

function evExpress(expression $, indsname $, curobs);
  file log;
  length macVarNameCheck macVarNamePassed $ 32 rc 8 marker $ 16 checkExpr 8;
  static done 0 macVarNameCheck macVarNamePassed;

  if not done then
    do;
      marker=put(datetime(),hex16.);
      macVarNameCheck=catx("_","EEF_CHECK",marker);
      macVarNamePassed=catx("_","EEF_PASSED",marker);
      /*put macVarNameCheck= macVarNamePassed=;*/
      done=1;
    end;

  rc = DoSubL(
    'options nonotes nosource nomprint nosymbolgen nomlogic ps=min ls=86;' !! 
    '%let ' !! macVarNameCheck !! '=0; %let ' !! macVarNamePassed !! '=.;' !!
    'data _null_ / NOTE2ERR;' !! 
    ifc(indsname=" "
       ," "
       ,cat('set ', strip(indsname), '(firstobs = ', max(curobs,1), ' obs = ', max(curobs,1), ');')) !! 
    ' call symputX("' !! macVarNamePassed !! '",(' !! strip(expression) !! '), "G"); stop; run;' !!
    ' /* ''; "; run; quit; */ %let ' !! macVarNameCheck !! '=%sysevalf(&SYSERR.+%length(&SYSERRORTEXT.));'
    );
  checkExpr  = symgetn(macVarNameCheck);

  length resultExpr 8;
  resultExpr = symgetn(macVarNamePassed);

  if checkExpr>0 then 
    do;
      put "WARNING: Problem in obs" curobs "for expression: " expression;
    end;
  return(resultExpr);
endfunc;

/*** HELP START ***//*

### EXAMPLES AND USECASES: ####################################################

**EXAMPLE 1.** Basic use case - evaluate expressions in the `code` variable:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas
data have;
 length x y 8 c $ 1 code $ 50;
 code = '(x > 1) and c="A"';             x= 3; y=11; c="A"; output;
 code = '(x < 1 and (9 < y < 13))';      x=-3; y=17; c="B"; output;
 code = '(x < 1) or C in ("C","D","E")'; x= 3; y=11; c="C"; output;
 code = '(3 - sqrt(x+y))';               x= 5; y=11; c="D"; output;
 code = '(12 + sum(of x--y))';           x= 3; y=9;  c="E"; output;
 code = 'sin(x)**2 + cos(x)**2';         x=-3; y=11; c="F"; output;
run;

data want;
  set have 
    curobs=curobs 
    indsname=indsname;

  value = evExpress(code, indsname, curobs);
run;

proc print data=want;
run;
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

**EXAMPLE 2.** Errors are returned for implicit types conversion:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas
data have2;
 length c $ 1 expression $ 50;
 expression = '"A" > 2'; c="G"; output;
 expression = ' C  < 2'; c="H"; output;
 expression = ' C ** 2'; c="I"; output;
run;

data want2;
  set have2 
    curobs=curobs 
    indsname=indsname;

  value = evExpress(expression, indsname, curobs);
run;

proc print data=want2;
run;
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

**EXAMPLE 3.** Execution time considerations (use `have` from Ex.1):
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas
data haveBigger;
  set have;
  do i=1 to 1000;
    output;
  end;
  rename code = expression;
run;

data wantBigger;
  set haveBigger 
    curobs=curobs 
    indsname=indsname;

  value = evExpress(expression, indsname, curobs);
run;
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Log note:

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
NOTE: DATA statement used (Total process time):
      real time           16.80 seconds
      cpu time            15.62 seconds
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

**EXAMPLE 4.** Constant expressions:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas
data constantExpressions;
  infile cards;
  input;
  length exp $ 128;
  exp = strip(_infile_);
cards;
1 and (1 or 0)
3+5+7
2**8
("A"="B") + 17
3+2=5
;
run;

data want3;
  set constantExpressions;
  value = evExpress(exp,"",0);
run;

proc print data=want3;
run;
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

---

*//*** HELP END ***/


/**###################################################################**/
/*                                                                     */
/*  Copyright Bartosz Jablonski, since 2025 onward.                    */
/*                                                                     */
/*  Code is under the MIT license. If you want - you can use it.       */
/*  But it comes "AS IS", with absolutely no warranty whatsoever.      */
/*  If you cause any damage or something - it will be your own fault.  */
/*  You've been warned! You are using it on your own risk.             */
/*                                                                     */
/*  However, if you decide to use it, you are obligated to mention     */
/*  the author Bartosz Jablonski (yabwon@gmail.com)                    */
/*                                                                     */
/**###################################################################**/


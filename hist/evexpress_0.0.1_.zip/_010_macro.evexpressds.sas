/* File generated with help of SAS Packages Framework, version 20251126. */

/*** HELP START ***//*

### DESCRIPTION: ##############################################################

The `%evExpressDS()` macro allows for automatic evaluation of expressions
provided in form of a text string in context of an observation from an 
input data set. By default macro assumes the result of the evaluation 
is *numeric*, but it can be altered.

For example if the input data set `have` contains the following data:


|  code  |  A  |  B  |
|:-------|:---:|:---:|
| A + B  |  17 |  42 |
| A = B  | 100 | 101 |
| A or B |   1 |   0 |

the result data set `want` will contain 2 additional variables:
`errorCheck` and `result`, containing status and value of the
expression execution, respectively:

|  code  |  A  |  B  | errorCheck | result |
|:-------|:---:|:---:|:----------:|:------:|
| A + B  |  17 |  42 |      0     |     59 |
| A = B  | 100 | 101 |      0     |      0 |
| A or B |   1 |   0 |      0     |      1 |

If the `errorCheck` is non-zero, this means that the expression could not
be evaluated due to an error.

### SYNTAX: ###################################################################

The basic syntax is the following, the `<...>` means optional parameters:
~~~~~~~~~~~~~~~~~~~~~~~sas
%evExpressDS(
   have
 <,want=>
 <,exp=>
 <,ec=>
 <,res=>
 <,engine=>
 <,quiet=>
 <,strict=>
 <,numeric=1>
)
~~~~~~~~~~~~~~~~~~~~~~~

**Arguments description**:

1. `have`    - *Required.* Valid data set name.
                If the data set does not exist, the macro stops.
                No data set options should be used.
                In particular, the `where=` option is not recommended.

* `want=`    - *Optional.* Valid data set name.
                Name of the result data set created by the macro.
                Default value is `WORK.WANT`. 

* `exp=`     - *Optional.* Valid variable name. 
                Name of a character variable containing 
                expression string for evaluation. 
                Default value is `expression`. 

* `ec=`      - *Optional.* Valid variable name. 
                Name of a *numeric* variable containing return 
                code from expression evaluation. Non-zero value 
                means that an error occurred while expression 
                evaluation.
                Default value is `errorCheck`. 

* `res=`     - *Optional.* Valid variable name. 
                Name of a *numeric* variable containing 
                result of the expression evaluation. 
                Default value is `result`. 

* `engine=`  - *Optional.* Valid name of SAS engine. 
                Only BASE(V9) and SPDE engines are supported.
                Default value is `BASE`. 

* `quiet=`   - *Optional.* Indicates if execution errors and 
                notes should be printed in the log. 
                Allowed values are `1` and `0`.
                Default value of `1` means: do not print.

* `strict=`  - *Optional.* Indicates if the implicit type conversion 
                is considered an errors. Allowed values are `1` and `0`.
                Default value of `1` means: conversion is an error.

* `char=`   - *Optional.* Indicates if the result variable is numeric
               or character. Allowed values are integers from `0` to `32767`.
               Default value of `0` means: variable is numeric.
               Other value also sets character variable length.



---

*//*** HELP END ***/

%macro evExpressDS(
 have
,want=WORK.WANT
,exp=expression
,ec=errorCheck
,res=result
,engine=BASE
,quiet=1
,strict=1
,char=0
)/minoperator secure;
%local time CHECK1 PASSED1 logPrinttoTmp;
%let time = %sysfunc(datetime());

%let engine = %upcase(%superq(engine));
%if NOT (%superq(engine) in (BASE V9 SPDE)) %then
  %do;
    %put WARNING:[&sysmacroname.] Only BASE and SPDE engines are supported. Exiting.;
    %return;
  %end;

%let quiet = %sysevalf(%superq(quiet)=1.0,boolean); 
%let strict = %sysevalf(%superq(strict)=1.0,boolean);

/*$$$$$$$$$$$$$$$$$$$$$$$$*/
%if 1=%superq(quiet) %then
  %do;
    %let logPrinttoTmp = &sysprinttolog.;
    %if %superq(logPrinttoTmp)= %then %let logPrinttoTmp=LOG;
    /*%put ######### %superq(logPrinttoTmp) ##########;*/
    filename ___D___ DUMMY;
    proc printto log=___D___;
    run;
  %end;

/*$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$*/
%if 1=%sysfunc(exist(%superq(have))) %then
%do;
  data &want.;
    set &have. 
        curobs=curobs 
        indsname=indsname;

    if not missing(&exp.) then 
      do;
        length strX $ 4096;
        drop strX rc;
        strX = cat(
          strip(indsname)
          %if %superq(engine)=SPDE %then
            %do;
              , '(startobs = ', curobs  /* <-- */
              , '   endobs = ', curobs  /* <-- */
            %end;
          %else /* BASE and V9 */
            %do;
              , '(firstobs = ', curobs  /* <-- */
              , '      obs = ', curobs  /* <-- */
            %end;
          , ');' 
          );
        %if 0=%superq(quiet) %then 
          %do;
            put "=START=" 80*"="/ &exp. / 87*"=" / ;
          %end;
          rc = DoSubL('options ' !! 
                      %if 1=%superq(quiet) %then
                        %do;
                          ' nonotes ' !! 
                        %end;
                     ' ps=min ls=86; %let CHECK1=0; %let PASSED1=;' !! 
                     'data _null_ ' !! ifc(symgetn('strict')=1,'/ NOTE2ERR', " ") !! '; set ' !! strX !! 
                     ' call symputX("PASSED1",(' !! strip(&exp.) !! '),"G"); stop; run;' !! /* evaluate expr */
                     '/* ''; "; run; quit; */ ' !! /* cover unmatched quotes */
                     '%let CHECK1=%sysevalf(&SYSERR.+%length(&SYSERRORTEXT.));' 
                     );
        %if 0=%superq(quiet) %then 
          %do;
            put "=END=" 82*"=" / ;
          %end;
        &ec.  = symgetn('CHECK1');        
        %if 0=%superq(char) %then 
          %do;
            &res. = symgetn('PASSED1');
          %end;
        %else
          %do;
            length &res. $ &char.;
            &res. = symget('PASSED1');
          %end;
      end;
    output;
  run;
%end;

/*$$$$$$$$$$$$$$$$$$$$$$$$*/
%if 1=%superq(quiet) %then
  %do;
    filename ___D___ CLEAR;
    proc printto log = &logPrinttoTmp.;
    run;
  %end;

%let time = %sysevalf( %sysfunc(datetime()) - &time. +0 );

%put NOTE:[&sysmacroname.] Processing time: &time.;
/*%put _local_;*/
%mend evExpressDS;

/*** HELP START ***//*

### EXAMPLES AND USECASES: ####################################################

**EXAMPLE 1.** Basic use case - evaluate expressions in the `code` variable:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas
data have;
 length x y 8 c $ 1 code $ 50;
 code = '(x > 1) and c="A"';             x= 3; y=11; c="A"; output;
 code = '(x < 1 and (9 < y < 13))';      x=-3; y=17; c="B"; output;
 code = '(x < 1) or C in ("C","D","E")'; x= 3; y=11; c="C"; output;
 code = '(3 - sqrt(x+y))';               x= 5; y=11; c="D"; output;
 code = '(12 + sum(of x--y))';           x= 3; y=9;  c="E"; output;
 code = 'sin(x)**2 + cos(x)**2';         x=-3; y=11; c="F"; output;
run;

%evExpressDS(have,exp=code)

proc print data=work.want;
run;
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

**EXAMPLE 2.** Compare implicit types conversion:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas
data have2;
 length c $ 1 expression $ 50;
 expression = '"A" > 2'; c="G"; output;
 expression = ' C < 2';  c="H"; output;
run;

%evExpressDS(have2,want=work.want2str)

proc print data=work.want2str;
run;

%evExpressDS(have2,want=work.want2nostr,strict=0)

proc print data=work.want2nostr;
run;
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

**EXAMPLE 3.** Execution time considerations (use `have` from Ex.1):
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas
data haveBigger;
  set have;
  do i=1 to 1000;
    output;
  end;
  rename code = expression;
run;

%evExpressDS(haveBigger,want=work.wantBigger)

proc print data=work.wantBigger;
run;
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Note produced: "[EVEXPRESSDS] Processing time: 16.227" seconds.


**EXAMPLE 4.** Expression that evaluates to character value:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas
data have4;
 length c $ 1 expression $ 50;
 expression = '"A" !! C !! "B"'; c="i"; output;
 expression = 'repeat(C, 42)';   c="j"; output;
run;

%evExpressDS(have4,want=work.want4,char=43)

proc print data=work.want4;
run;
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

---

*//*** HELP END ***/


/**###################################################################**/
/*                                                                     */
/*  Copyright Bartosz Jablonski, since 2025 onward.                    */
/*                                                                     */
/*  Code is under the MIT license. If you want - you can use it.       */
/*  But it comes "AS IS", with absolutely no warranty whatsoever.      */
/*  If you cause any damage or something - it will be your own fault.  */
/*  You've been warned! You are using it on your own risk.             */
/*                                                                     */
/*  However, if you decide to use it, you are obligated to mention     */
/*  the author Bartosz Jablonski (yabwon@gmail.com)                    */
/*                                                                     */
/**###################################################################**/

